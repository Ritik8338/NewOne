import json

def lambda_handler(event, context):
    # Sample Lambda function code
    # This function simply returns a response with a "message" key.

    # Get the name from the event payload
    name = event.get('name', 'Guest')

    # Create a response JSON
    response = {
        "message": f"Hello, {name}! This is a Lambda function response."
    }

    return {
        "statusCode": 200,
        "body": json.dumps(response)
    }
